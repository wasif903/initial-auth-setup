create extension if not exists pgcrypto;

create table quizzes (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  status text not null default 'draft'
    check (status in ('draft', 'published', 'archived')),
  created_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table sections (
  id uuid primary key default gen_random_uuid(),
  quiz_id uuid not null references quizzes(id) on delete cascade,
  title text not null,
  subtitle text,
  display_order int not null default 0,
  created_at timestamptz not null default now()
);

create index idx_sections_quiz_id on sections(quiz_id);

create table fields (
  id uuid primary key default gen_random_uuid(),
  section_id uuid not null references sections(id) on delete cascade,
  name text not null,
  label text not null,
  subtitle text,
  placeholder text,
  field_type text not null
    check (field_type in (
      'number', 'text', 'textarea', 'date',
      'single_choice', 'multi_choice',
      'slider', 'toggle'
    )),
  display_style text not null default 'default'
    check (display_style in (
      'default', 'dropdown', 'pills', 'icon_grid', 'radio', 'stepped'
    )),
  required boolean not null default false,
  display_order int not null default 0,
  config jsonb not null default '{}'::jsonb,
  visible_if jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (section_id, name)
);

create index idx_fields_section_id on fields(section_id);

create table field_options (
  id uuid primary key default gen_random_uuid(),
  field_id uuid not null references fields(id) on delete cascade,
  value text not null,
  label text not null,
  icon text,
  display_order int not null default 0,
  unique (field_id, value)
);

create index idx_field_options_field_id on field_options(field_id);

create table quiz_responses (
  id uuid primary key default gen_random_uuid(),
  quiz_id uuid not null references quizzes(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  status text not null default 'in_progress'
    check (status in ('in_progress', 'submitted')),
  current_section_id uuid references sections(id),
  started_at timestamptz not null default now(),
  submitted_at timestamptz
);

create index idx_quiz_responses_quiz_id on quiz_responses(quiz_id);
create index idx_quiz_responses_user_id on quiz_responses(user_id);

create unique index uq_one_in_progress_per_user
  on quiz_responses(quiz_id, user_id)
  where status = 'in_progress';

create table answers (
  id uuid primary key default gen_random_uuid(),
  response_id uuid not null references quiz_responses(id) on delete cascade,
  field_id uuid not null references fields(id) on delete cascade,
  value jsonb not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (response_id, field_id)
);

create index idx_answers_response_id on answers(response_id);
create index idx_answers_field_id on answers(field_id);

create or replace function set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger set_quizzes_updated_at
  before update on quizzes
  for each row execute function set_updated_at();

create trigger set_fields_updated_at
  before update on fields
  for each row execute function set_updated_at();

create trigger set_answers_updated_at
  before update on answers
  for each row execute function set_updated_at();

alter table quizzes enable row level security;
alter table sections enable row level security;
alter table fields enable row level security;
alter table field_options enable row level security;
alter table quiz_responses enable row level security;
alter table answers enable row level security;
