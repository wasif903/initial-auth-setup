create table profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  email text not null unique,
  phone text unique,
  first_name text,
  last_name text,
  providers text[] not null default '{}'::text[],
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table password_reset_challenges (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  channel text not null check (channel in ('email', 'whatsapp')),
  destination text not null,
  otp_hash text not null,
  expires_at timestamptz not null,
  attempts int not null default 0 check (attempts >= 0),
  verified_at timestamptz,
  reset_token_hash text unique,
  reset_token_expires_at timestamptz,
  consumed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index idx_password_reset_challenges_user_created
  on password_reset_challenges(user_id, created_at desc);

create index idx_password_reset_challenges_reset_token
  on password_reset_challenges(reset_token_hash)
  where reset_token_hash is not null;

create trigger set_profiles_updated_at
  before update on profiles
  for each row execute function set_updated_at();

create trigger set_password_reset_challenges_updated_at
  before update on password_reset_challenges
  for each row execute function set_updated_at();

alter table profiles enable row level security;
alter table password_reset_challenges enable row level security;
