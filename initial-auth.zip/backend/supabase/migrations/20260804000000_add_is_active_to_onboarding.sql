-- Add is_active column to onboarding.sections
ALTER TABLE onboarding.sections ADD COLUMN is_active BOOLEAN NOT NULL DEFAULT true;

-- Add is_active column to onboarding.fields
ALTER TABLE onboarding.fields ADD COLUMN is_active BOOLEAN NOT NULL DEFAULT true;
