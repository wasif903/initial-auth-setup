﻿export type Json =
    | string
    | number
    | boolean
    | null
    | { [key: string]: Json | undefined }
    | Json[];

export type Relationship = {
    foreignKeyName: string;
    columns: string[];
    isOneToOne: boolean;
    referencedRelation: string;
    referencedColumns: string[];
};

export type TableDefinition<
    Row extends Record<string, unknown>,
    Insert extends Record<string, unknown>,
    Update extends Record<string, unknown>,
> = {
    Row: Row;
    Insert: Insert;
    Update: Update;
    Relationships: [];
};
