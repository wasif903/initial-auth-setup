﻿import type { AuthRole } from "../modules/auth/auth.roles";

export type AuthUser = {
  id: string;
  email: string | null;
  phone: string | null;
  app_metadata: {
    role?: AuthRole;
    providers?: string[];
    disabled?: boolean;
    [key: string]: unknown;
  };
  user_metadata: {
    first_name?: string | null;
    last_name?: string | null;
    full_name?: string | null;
    given_name?: string | null;
    family_name?: string | null;
    phone?: string | null;
    [key: string]: unknown;
  };
  disabled: boolean;
  created_at: string;
  updated_at: string;
};

export type AuthSession = {
  access_token: string;
  refresh_token: string;
  token_type: "bearer";
  expires_in: number;
  expires_at: number;
};

