import type { AuthTables } from "../modules/auth/auth.database";

export type { Json } from "./database.shared";

export interface Database {
    public: {
        Tables: {
            users: AuthTables["users"];
            profiles: AuthTables["profiles"];
            auth_otp_challenges: AuthTables["auth_otp_challenges"];
            auth_refresh_tokens: AuthTables["auth_refresh_tokens"];
        };
        Views: Record<string, never>;
        Functions: Record<string, never>;
        Enums: Record<string, never>;
        CompositeTypes: Record<string, never>;
    };
}