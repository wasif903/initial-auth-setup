import type { Response } from "express";
import { env } from "../config/env";

export const ADMIN_REFRESH_COOKIE = "nutryx_admin_refresh";

const refreshCookieOptions = {
    httpOnly: true,
    secure: env.NODE_ENV === "production",
    sameSite: env.NODE_ENV === "production" ? "none" as const : "lax" as const,
    path: "/auth",
    maxAge: 30 * 24 * 60 * 60 * 1000,
};

export const setAdminRefreshCookie = (
    response: Response,
    refreshToken: string,
): void => {
    response.cookie(ADMIN_REFRESH_COOKIE, refreshToken, refreshCookieOptions);
};

export const clearAdminRefreshCookie = (response: Response): void => {
    response.clearCookie(ADMIN_REFRESH_COOKIE, refreshCookieOptions);
};
