﻿import { AppError } from "./AppError";

export const normalizeEmail = (email: string): string => email.trim().toLowerCase();

export const normalizePhone = (phone: string): string => {
    const normalized = phone.replace(/[\s()-]/g, "");
    if (!/^\+[1-9]\d{7,14}$/.test(normalized)) {
        throw new AppError("Phone number must use E.164 format, for example +923001234567", 400, "INVALID_PHONE");
    }
    return normalized;
};

export const normalizeIdentifier = (identifier: string): string =>
    identifier.includes("@") ? normalizeEmail(identifier) : normalizePhone(identifier);
