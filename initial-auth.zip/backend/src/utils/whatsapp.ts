﻿import { env } from "../config/env";
import { AppError } from "./AppError";

export const sendPasswordResetWhatsApp = async (recipient: string, otp: string): Promise<void> => {
    const response = await fetch(`https://graph.facebook.com/${env.META_WHATSAPP_API_VERSION}/${env.META_WHATSAPP_PHONE_NUMBER_ID}/messages`, {
        method: "POST",
        headers: { Authorization: `Bearer ${env.META_WHATSAPP_ACCESS_TOKEN}`, "Content-Type": "application/json" },
        body: JSON.stringify({
            messaging_product: "whatsapp",
            to: recipient.replace(/^\+/, ""),
            type: "template",
            template: {
                name: env.META_WHATSAPP_OTP_TEMPLATE_NAME,
                language: { code: env.META_WHATSAPP_TEMPLATE_LANGUAGE },
                components: [
                    { type: "body", parameters: [{ type: "text", text: otp }] },
                    { type: "button", sub_type: "url", index: "0", parameters: [{ type: "text", text: otp }] },
                ],
            },
        }),
    });
    if (!response.ok) {
        console.error("Meta WhatsApp API error:", await response.text());
        throw new AppError("Unable to send the WhatsApp reset code", 502, "WHATSAPP_SEND_FAILED");
    }
};
