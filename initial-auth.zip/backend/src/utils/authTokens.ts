import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import { env } from "../config/env";
import type { AuthUser, AuthSession } from "../types/auth";
import { hashSecret } from "./crypto";

type AccessTokenPayload = {
  sub: string;
  email: string | null;
  role: string;
  type: "access";
  iat: number;
  exp: number;
};

const base64Url = (value: string | Buffer): string =>
  Buffer.from(value)
    .toString("base64")
    .replace(/=/g, "")
    .replace(/\+/g, "-")
    .replace(/\//g, "_");

const fromBase64Url = (value: string): Buffer => {
  const padded = value + "=".repeat((4 - (value.length % 4)) % 4);
  return Buffer.from(padded.replace(/-/g, "+").replace(/_/g, "/"), "base64");
};

const sign = (input: string): string =>
  base64Url(createHmac("sha256", env.JWT_SECRET).update(input).digest());

export const createAccessToken = (user: AuthUser): Pick<AuthSession, "access_token" | "expires_at" | "expires_in" | "token_type"> => {
  const issuedAt = Math.floor(Date.now() / 1000);
  const expiresAt = issuedAt + env.JWT_ACCESS_EXPIRES_SECONDS;
  const payload: AccessTokenPayload = {
    sub: user.id,
    email: user.email,
    role: typeof user.app_metadata.role === "string" ? user.app_metadata.role : "user",
    type: "access",
    iat: issuedAt,
    exp: expiresAt,
  };
  const header = base64Url(JSON.stringify({ alg: "HS256", typ: "JWT" }));
  const body = base64Url(JSON.stringify(payload));
  const signature = sign(`${header}.${body}`);
  return {
    access_token: `${header}.${body}.${signature}`,
    token_type: "bearer",
    expires_in: env.JWT_ACCESS_EXPIRES_SECONDS,
    expires_at: expiresAt,
  };
};

export const verifyAccessToken = (token: string): AccessTokenPayload => {
  const parts = token.split(".");
  if (parts.length !== 3) throw new Error("Malformed token");

  const [header, body, signature] = parts;
  const expected = sign(`${header}.${body}`);
  const actualBuffer = Buffer.from(signature);
  const expectedBuffer = Buffer.from(expected);
  if (
    actualBuffer.length !== expectedBuffer.length ||
    !timingSafeEqual(actualBuffer, expectedBuffer)
  ) {
    throw new Error("Invalid token signature");
  }

  const payload = JSON.parse(fromBase64Url(body).toString("utf8")) as AccessTokenPayload;
  if (payload.type !== "access" || payload.exp <= Math.floor(Date.now() / 1000)) {
    throw new Error("Expired token");
  }
  return payload;
};

export const createRefreshToken = () => randomBytes(32).toString("hex");
export const hashRefreshToken = (token: string) => hashSecret(`refresh:${token}`);
