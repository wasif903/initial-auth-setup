﻿import { createHash, randomBytes, randomInt, timingSafeEqual } from "node:crypto";
import { env } from "../config/env";

export const generateOtp = (): string => randomInt(0, 1_000_000).toString().padStart(6, "0");
export const generateOpaqueToken = (): string => randomBytes(32).toString("hex");
export const hashSecret = (value: string): string => createHash("sha256").update(`${env.OTP_PEPPER}:${value}`).digest("hex");
export const secretsMatch = (value: string, expectedHash: string): boolean => {
    const actual = Buffer.from(hashSecret(value), "hex");
    const expected = Buffer.from(expectedHash, "hex");
    return actual.length === expected.length && timingSafeEqual(actual, expected);
};
