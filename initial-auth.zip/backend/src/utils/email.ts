﻿import nodemailer, { type Transporter } from "nodemailer";
import ejs from "ejs";
import path from "path";
import { env } from "../config/env";

let transporter: Transporter | undefined;
const getTransporter = (): Transporter => {
    transporter ??= nodemailer.createTransport({
        host: env.SMTP_HOST,
        port: env.SMTP_PORT,
        secure: env.SMTP_SECURE,
        auth: { user: env.SMTP_USER, pass: env.SMTP_PASS },
    });
    return transporter;
};
export const sendPasswordlessOtpEmail = async (recipient: string, otp: string): Promise<void> => {
    await getTransporter().sendMail({
        from: env.SMTP_FROM,
        to: recipient,
        subject: "Your Nutryx login code",
        text: `Your Nutryx login code is ${otp}. It expires in ${env.OTP_EXPIRY_MINUTES} minutes.`,
        html: `<p>Your Nutryx login code is:</p><p style="font-size:24px;font-weight:700;letter-spacing:6px">${otp}</p><p>This code expires in ${env.OTP_EXPIRY_MINUTES} minutes.</p>`,
    });
};
export const sendPasswordResetEmail = sendPasswordlessOtpEmail;
export const sendEmailWithTemplate = async (
    recipient: string,
    subject: string,
    htmlContent: string,
): Promise<void> => {
    await getTransporter().sendMail({
        from: env.SMTP_FROM,
        to: recipient,
        subject,
        html: htmlContent,
    });
};
export const sendEJSTemplateEmail = async (
    recipient: string,
    subject: string,
    templateName: string,
    data: any
): Promise<void> => {
    const templatePath = path.join(process.cwd(), 'src', 'utils', 'templates', templateName);
    const htmlContent = (await ejs.renderFile(templatePath, data)) as string;
    await getTransporter().sendMail({
        from: env.SMTP_FROM,
        to: recipient,
        subject,
        html: htmlContent,
    });
};
