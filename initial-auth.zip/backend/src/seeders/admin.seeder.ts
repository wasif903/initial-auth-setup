﻿import "dotenv/config";
import { query } from "../config/database";
import { env } from "../config/env";

export const seedAdminAccounts = async (): Promise<void> => {
    const adminEmails = env.ADMIN_EMAILS
        .split(",")
        .map((email) => email.trim().toLowerCase())
        .filter(Boolean);

    for (const email of adminEmails) {
        await query(
            `insert into users (email, app_metadata, user_metadata)
             values ($1, $2::jsonb, $3::jsonb)
             on conflict (email) do update
             set app_metadata = users.app_metadata || excluded.app_metadata,
                 updated_at = now()`,
            [
                email,
                JSON.stringify({ role: "admin", providers: ["passwordless"] }),
                JSON.stringify({}),
            ],
        );
        console.log(`Seeded Admin account: ${email}`);
    }
};

if (require.main === module) {
    seedAdminAccounts().catch((error: unknown) => {
        console.error(error instanceof Error ? error.message : error);
        process.exitCode = 1;
    });
}
