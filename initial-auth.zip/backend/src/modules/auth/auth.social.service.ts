import { createPublicKey, verify as verifySignature } from "node:crypto";
import { env } from "../../config/env";
import { AppError } from "../../utils/AppError";

export type SocialProvider = "google" | "apple";
type JwtPayload = Record<string, unknown>;
type JwkResponse = { keys?: JsonWebKey[] };

const providers: Record<SocialProvider, { clientId?: string; issuers: string[]; jwksUrl: string }> = {
  google: { clientId: env.GOOGLE_CLIENT_ID, issuers: ["https://accounts.google.com", "accounts.google.com"], jwksUrl: "https://www.googleapis.com/oauth2/v3/certs" },
  apple: { clientId: env.APPLE_CLIENT_ID, issuers: ["https://appleid.apple.com"], jwksUrl: "https://appleid.apple.com/auth/keys" },
};
const cache = new Map<SocialProvider, { keys: JsonWebKey[]; expiresAt: number }>();
const invalidToken = () => new AppError("Invalid social identity token", 401, "SOCIAL_TOKEN_INVALID");
const decode = <T>(value: string): T => JSON.parse(Buffer.from(value, "base64url").toString("utf8")) as T;

const jwks = async (provider: SocialProvider) => {
  const cached = cache.get(provider);
  if (cached && cached.expiresAt > Date.now()) return cached.keys;
  try {
    const response = await fetch(providers[provider].jwksUrl);
    const body = (await response.json()) as JwkResponse;
    if (!response.ok || !Array.isArray(body.keys)) throw new Error("Invalid JWKS response");
    cache.set(provider, { keys: body.keys, expiresAt: Date.now() + 60 * 60_000 });
    return body.keys;
  } catch {
    throw new AppError("Social provider verification is temporarily unavailable", 503, "SOCIAL_PROVIDER_UNAVAILABLE");
  }
};

export const verifySocialIdentityToken = async (provider: SocialProvider, token: string, nonce?: string) => {
  const configuration = providers[provider];
  if (!configuration.clientId) throw new AppError(`${provider} sign-in is not configured`, 503, "SOCIAL_PROVIDER_NOT_CONFIGURED");
  const parts = token.split(".");
  if (parts.length !== 3) throw invalidToken();
  let header: { alg?: string; kid?: string };
  let payload: JwtPayload;
  try { header = decode(parts[0]); payload = decode(parts[1]); } catch { throw invalidToken(); }
  const audience = payload.aud;
  const audienceMatches = audience === configuration.clientId || (Array.isArray(audience) && audience.includes(configuration.clientId));
  if (header.alg !== "RS256" || !header.kid || typeof payload.sub !== "string" || !configuration.issuers.includes(payload.iss as string) || !audienceMatches || typeof payload.exp !== "number" || payload.exp <= Math.floor(Date.now() / 1000) || (nonce && payload.nonce !== nonce)) throw invalidToken();
  const key = (await jwks(provider)).find((jwk) => (jwk as JsonWebKey & { kid?: string }).kid === header.kid);
  if (!key) throw invalidToken();
  try {
    const verified = verifySignature("RSA-SHA256", Buffer.from(`${parts[0]}.${parts[1]}`), createPublicKey({ key, format: "jwk" }), Buffer.from(parts[2], "base64url"));
    if (!verified) throw new Error("Invalid signature");
  } catch { throw invalidToken(); }
  if (provider === "google" && payload.email_verified !== true && payload.email_verified !== "true") throw new AppError("Google account email is not verified", 401, "SOCIAL_EMAIL_UNVERIFIED");
  return { subject: payload.sub as string, email: typeof payload.email === "string" ? payload.email : undefined, givenName: typeof payload.given_name === "string" ? payload.given_name : undefined, familyName: typeof payload.family_name === "string" ? payload.family_name : undefined, fullName: typeof payload.name === "string" ? payload.name : undefined };
};