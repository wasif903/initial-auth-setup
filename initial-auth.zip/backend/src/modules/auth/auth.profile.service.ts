﻿import { oneOrNull, query } from "../../config/database";
import type { AuthUser } from "../../types/auth";
import { AppError } from "../../utils/AppError";
import {
  normalizeEmail,
  normalizeIdentifier,
  normalizePhone,
} from "../../utils/normalization";
import type { ProfileRow } from "./auth.database";
import type { ProfileUpdateInput } from "./auth.schemas";

const PROFILE_COLUMNS =
  "user_id, email, phone, first_name, last_name, providers, created_at, updated_at";

export const mapUser = (row: any): AuthUser => ({
  id: row.id,
  email: row.email ?? null,
  phone: row.phone ?? null,
  app_metadata: row.app_metadata ?? {},
  user_metadata: row.user_metadata ?? {},
  disabled: Boolean(row.disabled),
  created_at: row.created_at,
  updated_at: row.updated_at,
});

export const findUserById = async (userId: string): Promise<AuthUser | null> => {
  const row = await oneOrNull(
    "select id, email, phone, app_metadata, user_metadata, disabled, created_at, updated_at from users where id = $1 and disabled = false",
    [userId],
  );
  return row ? mapUser(row) : null;
};

export const findProfileByIdentifier = async (
  identifier: string,
): Promise<ProfileRow> => {
  const normalized = normalizeIdentifier(identifier);
  const column = normalized.includes("@") ? "email" : "phone";
  const data = await oneOrNull<ProfileRow>(
    `select ${PROFILE_COLUMNS} from profiles where ${column} = $1`,
    [normalized],
  );

  if (!data) {
    throw new AppError(
      "Invalid account credentials",
      401,
      "INVALID_CREDENTIALS",
    );
  }
  return data;
};

export const findProfileByIdentifierOptional = async (
  identifier: string,
): Promise<ProfileRow | null> => {
  const normalized = normalizeIdentifier(identifier);
  const column = normalized.includes("@") ? "email" : "phone";
  return oneOrNull<ProfileRow>(
    `select ${PROFILE_COLUMNS} from profiles where ${column} = $1`,
    [normalized],
  );
};

const namesFromUser = (user: AuthUser) => {
  const metadata = user.user_metadata;
  const fullName =
    typeof metadata.full_name === "string"
      ? metadata.full_name.trim().split(/\s+/)
      : [];

  return {
    firstName:
      typeof metadata.first_name === "string"
        ? metadata.first_name
        : typeof metadata.given_name === "string"
          ? metadata.given_name
          : (fullName[0] ?? null),
    lastName:
      typeof metadata.last_name === "string"
        ? metadata.last_name
        : typeof metadata.family_name === "string"
          ? metadata.family_name
          : fullName.slice(1).join(" ") || null,
  };
};

export const ensureProfile = async (
  user: AuthUser,
  provider?: string,
): Promise<ProfileRow> => {
  const existing = await oneOrNull<ProfileRow>(
    `select ${PROFILE_COLUMNS} from profiles where user_id = $1`,
    [user.id],
  );

  const providers = Array.from(
    new Set([
      ...(existing?.providers ?? []),
      ...((user.app_metadata.providers as string[] | undefined) ?? []),
      ...(provider ? [provider] : []),
    ]),
  );

  if (existing) {
    if (providers.join("|") === existing.providers.join("|")) return existing;
    const updated = await oneOrNull<ProfileRow>(
      `update profiles set providers = $2, updated_at = now() where user_id = $1 returning ${PROFILE_COLUMNS}`,
      [user.id, providers],
    );
    if (!updated) {
      throw new AppError(
        "Unable to update profile",
        500,
        "PROFILE_UPDATE_FAILED",
      );
    }
    return updated;
  }

  if (!user.email) {
    throw new AppError(
      "Social provider did not return an email address",
      400,
      "SOCIAL_EMAIL_REQUIRED",
    );
  }

  const names = namesFromUser(user);
  const phone =
    typeof user.user_metadata.phone === "string"
      ? normalizePhone(user.user_metadata.phone)
      : user.phone;
  try {
    const created = await oneOrNull<ProfileRow>(
      `insert into profiles (user_id, email, phone, first_name, last_name, providers)
       values ($1, $2, $3, $4, $5, $6)
       returning ${PROFILE_COLUMNS}`,
      [user.id, normalizeEmail(user.email), phone, names.firstName, names.lastName, providers],
    );
    if (!created) throw new Error("Profile insert returned no row");
    return created;
  } catch (error: any) {
    if (error?.code === "23505") {
      throw new AppError("Email or phone is already in use", 409, "ACCOUNT_EXISTS");
    }
    throw new AppError(
      "Unable to create profile",
      500,
      "PROFILE_CREATE_FAILED",
    );
  }
};

export const updateProfile = async (
  userId: string,
  input: ProfileUpdateInput,
): Promise<ProfileRow> => {
  const updates = {
    ...input,
    ...(input.phone ? { phone: normalizePhone(input.phone) } : {}),
  };
  const keys = Object.keys(updates) as Array<keyof typeof updates>;
  const assignments = keys.map((key, index) => `${key} = $${index + 2}`);

  try {
    const data = await oneOrNull<ProfileRow>(
      `update profiles set ${assignments.join(", ")}, updated_at = now() where user_id = $1 returning ${PROFILE_COLUMNS}`,
      [userId, ...keys.map((key) => updates[key])],
    );
    if (!data) {
      throw new AppError(
        "Unable to update profile",
        500,
        "PROFILE_UPDATE_FAILED",
      );
    }

    if (updates.phone) {
      await query("update users set phone = $2, updated_at = now() where id = $1", [userId, updates.phone]);
    }
    return data;
  } catch (error: any) {
    if (error?.code === "23505") {
      throw new AppError("Phone number is already in use", 409, "PHONE_IN_USE");
    }
    if (error instanceof AppError) throw error;
    throw new AppError(
      "Unable to update profile",
      500,
      "PROFILE_UPDATE_FAILED",
    );
  }
};

