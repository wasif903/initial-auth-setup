﻿import { z } from "zod";

const emailSchema = z.string().trim().email();
const phoneSchema = z
  .string()
  .trim()
  .regex(/^\+[1-9]\d{7,14}$/, "Phone must use E.164 format");
const otpSchema = z.string().regex(/^\d{6}$/);

export const signupSchema = z
  .object({
    first_name: z.string().trim().min(1).max(100),
    last_name: z.string().trim().min(1).max(100),
    email: emailSchema,
    phone: phoneSchema,
  })
  .strict();

export const loginSchema = z
  .object({
    identifier: z.string().trim().min(1),
    channel: z.enum(["email", "whatsapp"]).default("email"),
  })
  .strict();

const optionalDateSchema = z
  .string()
  .trim()
  .regex(/^\d{4}-\d{2}-\d{2}$/)
  .optional();

export const professionalSchema = z
  .object({
    first_name: z.string().trim().min(1).max(100),
    last_name: z.string().trim().min(1).max(100),
    email: emailSchema,
    professional_type: z.enum(["trainer", "nutritionist"]),
    bio: z.string().trim().max(500).optional(),
    dob: optionalDateSchema,
    joining_date: optionalDateSchema,
    profile_picture_url: z.string().trim().min(1).optional(),
  })
  .strict();

export const adminLoginSchema = z
  .object({
    email: emailSchema,
    otp: otpSchema,
  })
  .strict();

export const socialLoginSchema = z
  .object({
    provider: z.enum(["google", "apple"]),
    token: z.string().min(1),
    access_token: z.string().min(1).optional(),
    nonce: z.string().min(1).optional(),
    email: emailSchema.optional(),
    first_name: z.string().trim().min(1).max(100).optional(),
    last_name: z.string().trim().min(1).max(100).optional(),
    full_name: z.string().trim().min(1).max(200).optional(),
  })
  .strict();

export const refreshSchema = z
  .object({
    refresh_token: z.string().min(1).optional(),
  })
  .strict();

export const profileUpdateSchema = z
  .object({
    first_name: z.string().trim().min(1).max(100).optional(),
    last_name: z.string().trim().min(1).max(100).optional(),
    phone: phoneSchema.optional(),
  })
  .strict()
  .refine((value) => Object.keys(value).length > 0, {
    message: "At least one profile field is required",
  });

export const forgotPasswordSchema = loginSchema;

export const verifyOtpSchema = z
  .object({
    challenge_id: z.string().uuid(),
    otp: otpSchema,
  })
  .strict();

export type ProfessionalInput = z.infer<typeof professionalSchema>;
export type SignupInput = z.infer<typeof signupSchema>;
export type LoginInput = z.infer<typeof loginSchema>;
export type AdminLoginInput = z.infer<typeof adminLoginSchema>;
export type SocialLoginInput = z.infer<typeof socialLoginSchema>;
export type ProfileUpdateInput = z.infer<typeof profileUpdateSchema>;
