﻿import type { Request, Response } from "express";
import type { AuthenticatedRequest } from "../../middlewares/auth";
import { AppError } from "../../utils/AppError";
import {
  ADMIN_REFRESH_COOKIE,
  clearAdminRefreshCookie,
  setAdminRefreshCookie,
} from "../../utils/authCookies";
import { AuthService } from "./auth.service";
import { getAuthRole, isAdmin } from "./auth.roles";
import {
  adminLoginSchema,
  forgotPasswordSchema,
  loginSchema,
  professionalSchema,
  profileUpdateSchema,
  refreshSchema,
  signupSchema,
  socialLoginSchema,
  verifyOtpSchema,
} from "./auth.schemas";

const authenticated = (request: Request) => {
  const authRequest = request as AuthenticatedRequest;
  if (!authRequest.authUser || !authRequest.accessToken)
    throw new AppError("Authentication required", 401, "UNAUTHORIZED");
  return authRequest;
};

const adminClientPayload = <
  TSession extends { refresh_token: string },
  TResult extends { session: TSession | null },
>(
  response: Response,
  result: TResult,
) => {
  if (!result.session) return result;
  setAdminRefreshCookie(response, result.session.refresh_token);
  const { refresh_token: _refreshToken, ...session } = result.session;
  return { ...result, session };
};

export class AuthController {
  static async signup(request: Request, response: Response) {
    const result = await AuthService.signup(signupSchema.parse(request.body));
    response.status(201).json({ success: true, data: result });
  }

  static async login(request: Request, response: Response) {
    const result = await AuthService.login(loginSchema.parse(request.body));
    response.json({ success: true, data: result });
  }

  static async adminLogin(request: Request, response: Response) {
    const result = await AuthService.adminLogin(
      adminLoginSchema.parse(request.body),
    );
    response.json({
      success: true,
      data: adminClientPayload(response, result),
    });
  }

  static async inviteProfessionals(request: Request, response: Response) {
    const authRequest = authenticated(request);
    if (!isAdmin(authRequest.authUser!)) {
      throw new AppError("Admin access required", 403, "ADMIN_ACCESS_REQUIRED");
    }
    if (request.file) {
      request.body.profile_picture_url = `/uploads/${request.file.filename}`;
    }
    const result = await AuthService.inviteProfessionals(
      professionalSchema.parse(request.body),
    );
    response.json({
      success: true,
      data: result,
    });
  }

  static async listProfessionals(request: Request, response: Response) {
    const authRequest = authenticated(request);
    if (!isAdmin(authRequest.authUser!)) {
      throw new AppError('Admin access required', 403, 'ADMIN_ACCESS_REQUIRED');
    }

    const q = request.query;
    const professional_type = typeof q.professional_type === 'string' ? (q.professional_type as 'trainer' | 'nutritionist') : undefined;
    const search = typeof q.search === 'string' ? q.search : undefined;
    const status = typeof q.status === 'string' && (q.status === 'active' || q.status === 'inactive') ? (q.status as 'active' | 'inactive') : undefined;
    const limit = q.limit ? Math.max(1, Math.min(100, Number(q.limit))) : 20;
    const cursor = typeof q.cursor === 'string' ? q.cursor : undefined;

    const result = await AuthService.listProfessionals({ professional_type, search, status, limit, cursor });
    response.json({ success: true, data: result });
  }

  static async socialLogin(request: Request, response: Response) {
    const result = await AuthService.socialLogin(
      socialLoginSchema.parse(request.body),
    );
    response.json({ success: true, data: result });
  }

  static async refresh(request: Request, response: Response) {
    const input = refreshSchema.parse(request.body);
    const refreshToken =
      input.refresh_token ?? request.cookies?.[ADMIN_REFRESH_COOKIE];
    if (!refreshToken) {
      throw new AppError(
        "Refresh token is required",
        401,
        "REFRESH_TOKEN_REQUIRED",
      );
    }
    try {
      const result = await AuthService.refresh(refreshToken);
      response.json({
        success: true,
        data:
          result.role === "admin"
            ? adminClientPayload(response, result)
            : result,
      });
    } catch (error) {
      clearAdminRefreshCookie(response);
      throw error;
    }
  }

  static async logout(request: Request, response: Response) {
    const authRequest = authenticated(request);
    await AuthService.logout(authRequest.accessToken!);
    clearAdminRefreshCookie(response);
    response.status(204).send();
  }

  static async me(request: Request, response: Response) {
    const authRequest = authenticated(request);
    response.json({
      success: true,
      data: await AuthService.getMe(authRequest.authUser!),
    });
  }

  static async testTokenVerification(request: Request, response: Response) {
    const authRequest = authenticated(request);
    const role = getAuthRole(authRequest.authUser!);
    if (role !== "admin") {
      throw new AppError("Admin access required", 403, "ADMIN_ACCESS_REQUIRED");
    }
    response.json({
      success: true,
      data: {
        valid: true,
        message: "Access token verified successfully",
        user: {
          id: authRequest.authUser!.id,
          email: authRequest.authUser!.email ?? null,
        },
        role,
      },
    });
  }

  static async updateProfile(request: Request, response: Response) {
    const authRequest = authenticated(request);
    const input = profileUpdateSchema.parse(request.body);
    response.json({
      success: true,
      data: await AuthService.updateProfile(authRequest.authUser!, input),
    });
  }

  static async forgotPassword(request: Request, response: Response) {
    const input = forgotPasswordSchema.parse(request.body);
    response.json({
      success: true,
      data: await AuthService.forgotPassword(input.identifier),
    });
  }

  static async forgotPasswordWhatsApp(request: Request, response: Response) {
    const input = forgotPasswordSchema.parse(request.body);
    response.json({
      success: true,
      data: await AuthService.forgotPasswordWhatsApp(input.identifier),
    });
  }

  static async verifyOtp(request: Request, response: Response) {
    const input = verifyOtpSchema.parse(request.body);
    const result = await AuthService.verifyOtp(input.challenge_id, input.otp);
    response.json({ success: true, data: result });
  }
}
