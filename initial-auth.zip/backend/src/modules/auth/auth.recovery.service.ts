﻿import { env } from "../../config/env";
import { oneOrNull, query } from "../../config/database";
import { AppError } from "../../utils/AppError";
import {
    generateOpaqueToken,
    hashSecret,
    secretsMatch,
} from "../../utils/crypto";
import { findProfileByIdentifier } from "./auth.profile.service";
import type { OtpChallengeRow } from "./auth.database";

type OtpChannel = "email" | "whatsapp";

const CHALLENGE_COLUMNS =
    "id, user_id, channel, destination, otp_hash, expires_at, attempts, verified_at, reset_token_hash, reset_token_expires_at, consumed_at, created_at, updated_at";

export const issueOtp = async (identifier: string, channel: OtpChannel = "email") => {
    const profile = await findProfileByIdentifier(identifier);
    const destination = channel === "email" ? profile.email : profile.phone;
    if (!destination) {
        throw new AppError(
            "No phone number is available for this account",
            400,
            "PHONE_REQUIRED",
        );
    }

    const latest = await oneOrNull<{ created_at: string }>(
        "select created_at from auth_otp_challenges where user_id = $1 and channel = $2 order by created_at desc limit 1",
        [profile.user_id, channel],
    );

    if (
        latest &&
        Date.now() - new Date(latest.created_at).getTime() <
            env.OTP_RESEND_SECONDS * 1000
    ) {
        throw new AppError(
            `Please wait ${env.OTP_RESEND_SECONDS} seconds before requesting another code`,
            429,
            "OTP_RATE_LIMITED",
        );
    }

    const otp = env.DEFAULT_PASSWORDLESS_OTP;
    const expiresAt = new Date(
        Date.now() + env.OTP_EXPIRY_MINUTES * 60_000,
    ).toISOString();
    const challenge = await oneOrNull<Pick<OtpChallengeRow, "id" | "expires_at">>(
        `insert into auth_otp_challenges (user_id, channel, destination, otp_hash, expires_at)
         values ($1, $2, $3, $4, $5)
         returning id, expires_at`,
        [profile.user_id, channel, destination, hashSecret(otp), expiresAt],
    );

    if (!challenge) {
        throw new AppError(
            "Unable to create OTP challenge",
            500,
            "OTP_CREATE_FAILED",
        );
    }

    await query(
        "update auth_otp_challenges set consumed_at = now() where user_id = $1 and id <> $2 and consumed_at is null",
        [profile.user_id, challenge.id],
    );

    return {
        challenge_id: challenge.id,
        channel,
        destination,
        expires_at: challenge.expires_at,
        otp: env.NODE_ENV === "production" ? undefined : otp,
    };
};

export const forgotPassword = (identifier: string) =>
    issueOtp(identifier, "email");

export const forgotPasswordWhatsApp = (identifier: string) =>
    issueOtp(identifier, "whatsapp");

export const verifyOtpChallenge = async (challengeId: string, otp: string) => {
    const challenge = await oneOrNull<OtpChallengeRow>(
        `select ${CHALLENGE_COLUMNS} from auth_otp_challenges where id = $1`,
        [challengeId],
    );

    if (
        !challenge ||
        challenge.consumed_at ||
        challenge.verified_at ||
        new Date(challenge.expires_at).getTime() <= Date.now()
    ) {
        throw new AppError("OTP is invalid or expired", 400, "INVALID_OTP");
    }
    if (challenge.attempts >= env.OTP_MAX_ATTEMPTS) {
        throw new AppError(
            "Too many incorrect OTP attempts",
            429,
            "OTP_ATTEMPTS_EXCEEDED",
        );
    }

    if (!secretsMatch(otp, challenge.otp_hash)) {
        await query(
            "update auth_otp_challenges set attempts = attempts + 1 where id = $1",
            [challenge.id],
        );
        throw new AppError("OTP is invalid or expired", 400, "INVALID_OTP");
    }

    await query(
        "update auth_otp_challenges set verified_at = now(), consumed_at = now() where id = $1",
        [challenge.id],
    );

    return { user_id: challenge.user_id };
};

export const verifyLatestOtpForUser = async (userId: string, otp: string) => {
    const latest = await oneOrNull<{ id: string }>(
        "select id from auth_otp_challenges where user_id = $1 and consumed_at is null order by created_at desc limit 1",
        [userId],
    );
    if (!latest) throw new AppError("OTP is invalid or expired", 400, "INVALID_OTP");
    return verifyOtpChallenge(latest.id, otp);
};

export const verifyOtp = async (challengeId: string, otp: string) => {
    const verified = await verifyOtpChallenge(challengeId, otp);
    const resetToken = generateOpaqueToken();
    const expiresAt = new Date(
        Date.now() + env.RESET_TOKEN_EXPIRY_MINUTES * 60_000,
    ).toISOString();
    await query(
        "update auth_otp_challenges set reset_token_hash = $2, reset_token_expires_at = $3 where id = $1",
        [challengeId, hashSecret(resetToken), expiresAt],
    );
    return { ...verified, reset_token: resetToken, expires_at: expiresAt };
};

export const resetPassword = async (): Promise<void> => {
    throw new AppError(
        "Password reset is disabled because passwordless authentication is enabled",
        410,
        "PASSWORD_AUTH_DISABLED",
    );
};
