﻿import { Router } from "express";
import multer from "multer";
import { authenticate } from "../../middlewares/auth";
import { asyncHandler } from "../../utils/asyncHandler";
import { AuthController } from "./auth.controller";

const upload = multer({ dest: "uploads/" });
const router = Router();

router.post("/signup", asyncHandler(AuthController.signup));
router.post("/login", asyncHandler(AuthController.login));
router.post("/otp/verify", asyncHandler(AuthController.verifyOtp));
router.post("/admin/login", asyncHandler(AuthController.adminLogin));
router.post("/social-login", asyncHandler(AuthController.socialLogin));
router.post("/refresh", asyncHandler(AuthController.refresh));
router.post("/password/forgot", asyncHandler(AuthController.forgotPassword));
router.post("/password/forgot/whatsapp", asyncHandler(AuthController.forgotPasswordWhatsApp));
router.post("/password/verify-otp", asyncHandler(AuthController.verifyOtp));
router.post("/logout", authenticate, asyncHandler(AuthController.logout));
router.get("/me", authenticate, asyncHandler(AuthController.me));
router.get("/test-token-verification", authenticate, asyncHandler(AuthController.testTokenVerification));
router.patch("/profile", authenticate, asyncHandler(AuthController.updateProfile));
router.post("/invite-professionals", authenticate, upload.single("profile_picture"), asyncHandler(AuthController.inviteProfessionals));
router.get("/professionals", authenticate, asyncHandler(AuthController.listProfessionals));

export default router;
