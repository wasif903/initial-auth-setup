﻿import type { AuthUser } from "../../types/auth";

export const AUTH_ROLES = ["user", "trainer", "nutritionist", "admin"] as const;

export type AuthRole = typeof AUTH_ROLES[number];

export const getAuthRole = (user: Pick<AuthUser, "app_metadata">): AuthRole => {
    const role = user.app_metadata.role;
    return typeof role === "string" && AUTH_ROLES.includes(role as AuthRole)
        ? role as AuthRole
        : "user";
};

export const isAdmin = (user: Pick<AuthUser, "app_metadata">): boolean =>
    getAuthRole(user) === "admin";
