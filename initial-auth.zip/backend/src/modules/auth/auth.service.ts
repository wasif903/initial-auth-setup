import { oneOrNull, query } from "../../config/database";
import { env } from "../../config/env";
import type { AuthSession, AuthUser } from "../../types/auth";
import { AppError } from "../../utils/AppError";
import { createAccessToken, createRefreshToken, hashRefreshToken, verifyAccessToken } from "../../utils/authTokens";
import { normalizeEmail, normalizeIdentifier, normalizePhone } from "../../utils/normalization";
import {
    ensureProfile,
    findProfileByIdentifier,
    findProfileByIdentifierOptional,
    findUserById,
    mapUser,
    updateProfile,
} from "./auth.profile.service";
import {
    forgotPassword,
    forgotPasswordWhatsApp,
    issueOtp,
    resetPassword,
    verifyLatestOtpForUser,
    verifyOtpChallenge,
} from "./auth.recovery.service";
import { getAuthRole, isAdmin } from "./auth.roles";
import { verifySocialIdentityToken } from "./auth.social.service";
import { sendEJSTemplateEmail } from "../../utils/email";
import type {
    AdminLoginInput,
    LoginInput,
    ProfessionalInput,
    ProfileUpdateInput,
    SignupInput,
    SocialLoginInput,
} from "./auth.schemas";

const publicUser = (user: AuthUser) => ({
    id: user.id,
    email: user.email,
    phone: user.phone,
    app_metadata: user.app_metadata,
    user_metadata: user.user_metadata,
    created_at: user.created_at,
    updated_at: user.updated_at,
});

const createSession = async (user: AuthUser): Promise<AuthSession> => {
    const access = createAccessToken(user);
    const refreshToken = createRefreshToken();
    const refreshExpiresAt = new Date(
        Date.now() + env.JWT_REFRESH_EXPIRES_DAYS * 24 * 60 * 60_000,
    ).toISOString();
    await query(
        "insert into auth_refresh_tokens (user_id, token_hash, expires_at) values ($1, $2, $3)",
        [user.id, hashRefreshToken(refreshToken), refreshExpiresAt],
    );
    return { ...access, refresh_token: refreshToken };
};

const adminAuthPayload = async (user: AuthUser, session: AuthSession | null) => ({
    user: {
        id: user.id,
        email: user.email ?? null,
    },
    session,
    role: "admin" as const,
});

const authPayload = async (
    user: AuthUser,
    session: AuthSession | null,
    provider?: string,
) => {
    const role = getAuthRole(user);
    if (role === "admin") {
        return adminAuthPayload(user, session);
    }

    const profile = await ensureProfile(user, provider);
    return {
        user: publicUser(user),
        session,
        role,
        profile,
    };
};

const createUser = async (input: {
    email: string;
    phone?: string | null;
    first_name?: string | null;
    last_name?: string | null;
    role?: string;
    providers: string[];
    socialIds?: Record<string, string>;
}): Promise<AuthUser> => {
    const appMetadata = {
        role: input.role ?? "user",
        providers: input.providers,
        ...(input.socialIds ? { social_ids: input.socialIds } : {}),
    };
    const userMetadata = {
        first_name: input.first_name ?? null,
        last_name: input.last_name ?? null,
        phone: input.phone ?? null,
    };
    const row = await oneOrNull(
        `insert into users (email, phone, app_metadata, user_metadata)
         values ($1, $2, $3::jsonb, $4::jsonb)
         returning id, email, phone, app_metadata, user_metadata, disabled, created_at, updated_at`,
        [input.email, input.phone ?? null, JSON.stringify(appMetadata), JSON.stringify(userMetadata)],
    );
    if (!row) throw new AppError("Unable to create account", 500, "SIGNUP_FAILED");
    return mapUser(row);
};

const findUserByEmail = async (email: string): Promise<AuthUser | null> => {
    const row = await oneOrNull(
        "select id, email, phone, app_metadata, user_metadata, disabled, created_at, updated_at from users where email = $1 and disabled = false",
        [email],
    );
    return row ? mapUser(row) : null;
};

export class AuthService {
    static async signup(input: SignupInput) {
        const email = normalizeEmail(input.email);
        const phone = normalizePhone(input.phone);
        const existing = await findProfileByIdentifierOptional(email).catch(() => null)
            ?? await findProfileByIdentifierOptional(phone).catch(() => null);

        if (existing) {
            throw new AppError(
                "An account with this email or phone already exists",
                409,
                "ACCOUNT_EXISTS",
            );
        }

        try {
            const user = await createUser({
                email,
                phone,
                first_name: input.first_name,
                last_name: input.last_name,
                providers: ["passwordless"],
            });
            await ensureProfile(user, "passwordless");
            const challenge = await issueOtp(email, "email");
            return {
                user: publicUser(user),
                role: getAuthRole(user),
                challenge,
                message: "Account created. Verify OTP to finish login.",
            };
        } catch (error: any) {
            if (error?.code === "23505") {
                throw new AppError(
                    "An account with this email or phone already exists",
                    409,
                    "ACCOUNT_EXISTS",
                );
            }
            if (error instanceof AppError) throw error;
            throw new AppError("Unable to create account", 500, "SIGNUP_FAILED");
        }
    }

    static async login(input: LoginInput) {
        const identifier = normalizeIdentifier(input.identifier);
        return issueOtp(identifier, input.channel);
    }

    static async verifyOtp(challengeId: string, otp: string) {
        const verified = await verifyOtpChallenge(challengeId, otp);
        const user = await findUserById(verified.user_id);
        if (!user) throw new AppError("Account not found", 404, "ACCOUNT_NOT_FOUND");
        const session = await createSession(user);
        return authPayload(user, session);
    }

    static async inviteProfessionals(input: ProfessionalInput) {
        const email = normalizeEmail(input.email);

        const validateEmail = await findProfileByIdentifierOptional(email);
        if (validateEmail) {
            throw new AppError(
                "An account with this email already exists",
                409,
                "ACCOUNT_EXISTS",
            );
        }

        const user = await createUser({
            email,
            first_name: input.first_name,
            last_name: input.last_name,
            role: input.professional_type,
            providers: ["passwordless"],
        });
        await ensureProfile(user, "passwordless");

        await sendEJSTemplateEmail(email, "You have been invited to Nutryx", "inviteProfessional.ejs", {
            firstName: input.first_name,
            lastName: input.last_name,
            email,
        });

        return authPayload(user, null, "passwordless");
    }

    static async listProfessionals(options: {
        professional_type?: 'trainer' | 'nutritionist';
        search?: string | null;
        status?: 'active' | 'inactive' | null;
        page?: number | null;
        pageSize?: number | null;
        cursor?: string | null;
        limit?: number;
    }) {
        const {
            professional_type,
            search,
            status,
            page,
            pageSize,
            cursor,
            limit = 20,
        } = options;
        const useOffset = typeof page === 'number' && typeof pageSize === 'number';
        const values: unknown[] = [];
        const where: string[] = ["coalesce(u.app_metadata->>'role', 'user') in ('trainer', 'nutritionist')"];

        if (professional_type) {
            values.push(professional_type);
            where.push(`u.app_metadata->>'role' = $${values.length}`);
        }
        if (status) {
            values.push(status === "inactive");
            where.push(`u.disabled = $${values.length}`);
        }
        if (search) {
            values.push(`%${search.replace(/%/g, '')}%`);
            where.push(`(p.first_name ilike $${values.length} or p.last_name ilike $${values.length} or p.email ilike $${values.length})`);
        }
        if (!useOffset && cursor) {
            values.push(cursor);
            where.push(`p.created_at < $${values.length}`);
        }

        const baseSql = `from profiles p join users u on u.id = p.user_id where ${where.join(" and ")}`;
        let paginationSql = "order by p.created_at desc";
        if (useOffset) {
            values.push(Math.max(1, pageSize!));
            values.push((Math.max(1, page!) - 1) * Math.max(1, pageSize!));
            paginationSql += ` limit $${values.length - 1} offset $${values.length}`;
        } else {
            values.push(Math.max(1, Math.min(100, limit)) + 1);
            paginationSql += ` limit $${values.length}`;
        }

        const rows = (await query(
            `select p.user_id as id, p.email, p.first_name, p.last_name, p.created_at, p.updated_at,
                    u.app_metadata->>'role' as role,
                    case when u.disabled then 'inactive' else 'active' end as status
             ${baseSql} ${paginationSql}`,
            values,
        )).rows;

        if (useOffset) {
            const countValues = values.slice(0, values.length - 2);
            const totalRow = await oneOrNull<{ count: string }>(`select count(*)::text ${baseSql}`, countValues);
            const totalItems = Number(totalRow?.count ?? 0);
            const size = pageSize || 20;
            return {
                items: rows,
                pagination: {
                    page: page || 1,
                    pageSize: size,
                    totalItems,
                    totalPages: Math.max(1, Math.ceil(totalItems / size)),
                },
            };
        }

        const hasMore = rows.length > limit;
        const pageItems = rows.slice(0, limit);
        const next_cursor = hasMore ? pageItems[pageItems.length - 1].created_at : null;
        return { items: pageItems, next_cursor };
    }

    static async adminLogin(input: AdminLoginInput) {
        const email = normalizeEmail(input.email);
        const user = await findUserByEmail(email);
        if (!user || !isAdmin(user)) {
            throw new AppError(
                "Admin access required",
                403,
                "ADMIN_ACCESS_REQUIRED",
            );
        }
        await verifyLatestOtpForUser(user.id, input.otp);
        return authPayload(user, await createSession(user));
    }

    static async socialLogin(input: SocialLoginInput) {
        const payload = await verifySocialIdentityToken(input.provider, input.token, input.nonce);
        const providerSubject = payload.subject;
        const rawEmail = payload.email;
        if (typeof rawEmail !== "string") {
            throw new AppError("Social provider did not return an email address", 400, "SOCIAL_EMAIL_REQUIRED");
        }
        const email = normalizeEmail(rawEmail);

        let user = await findUserByEmail(email);
        if (!user) {
            const fullName = input.full_name ?? payload.fullName;
            const names = typeof fullName === "string" ? fullName.trim().split(/\s+/) : [];
            user = await createUser({
                email,
                first_name: input.first_name ?? payload.givenName ?? names[0] ?? null,
                last_name: input.last_name ?? payload.familyName ?? (names.slice(1).join(" ") || null),
                providers: [input.provider],
                socialIds: { [input.provider]: providerSubject },
            });
        } else {
            const providers = Array.from(new Set([...(user.app_metadata.providers ?? []), input.provider]));
            const socialIds = {
                ...((user.app_metadata.social_ids as Record<string, string> | undefined) ?? {}),
                [input.provider]: providerSubject,
            };
            const row = await oneOrNull(
                `update users set app_metadata = $2::jsonb, updated_at = now()
                 where id = $1 returning id, email, phone, app_metadata, user_metadata, disabled, created_at, updated_at`,
                [user.id, JSON.stringify({ ...user.app_metadata, providers, social_ids: socialIds })],
            );
            if (row) user = mapUser(row);
        }

        const session = await createSession(user);
        return authPayload(user, session, input.provider);
    }

    static async refresh(refreshToken: string) {
        const tokenHash = hashRefreshToken(refreshToken);
        const token = await oneOrNull<{ id: string; user_id: string; expires_at: string; revoked_at: string | null }>(
            "select id, user_id, expires_at, revoked_at from auth_refresh_tokens where token_hash = $1",
            [tokenHash],
        );
        if (!token || token.revoked_at || new Date(token.expires_at).getTime() <= Date.now()) {
            throw new AppError(
                "Invalid or expired refresh token",
                401,
                "INVALID_REFRESH_TOKEN",
            );
        }
        await query("update auth_refresh_tokens set revoked_at = now() where id = $1", [token.id]);
        const user = await findUserById(token.user_id);
        if (!user) throw new AppError("Account not found", 404, "ACCOUNT_NOT_FOUND");
        return authPayload(user, await createSession(user));
    }

    static async logout(accessToken: string): Promise<void> {
        const payload = verifyAccessToken(accessToken);
        await query("update auth_refresh_tokens set revoked_at = now() where revoked_at is null and user_id = $1", [payload.sub]);
    }

    static getMe(user: AuthUser) {
        return authPayload(user, null);
    }

    static async updateProfile(user: AuthUser, input: ProfileUpdateInput) {
        if (isAdmin(user)) {
            throw new AppError(
                "Admin accounts do not have profiles",
                403,
                "ADMIN_PROFILE_UNAVAILABLE",
            );
        }
        const profile = await updateProfile(user.id, input);
        return {
            profile,
        };
    }

    static forgotPassword = forgotPassword;
    static forgotPasswordWhatsApp = forgotPasswordWhatsApp;
    static resetPassword = resetPassword;
}



