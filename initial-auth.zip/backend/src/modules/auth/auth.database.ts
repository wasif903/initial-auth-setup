﻿import type { TableDefinition } from "../../types/database.shared";

export type ProfileRow = {
    user_id: string;
    email: string;
    phone: string | null;
    first_name: string | null;
    last_name: string | null;
    providers: string[];
    created_at: string;
    updated_at: string;
};

export type UserRow = {
    id: string;
    email: string | null;
    phone: string | null;
    app_metadata: Record<string, unknown>;
    user_metadata: Record<string, unknown>;
    disabled: boolean;
    created_at: string;
    updated_at: string;
};

export type OtpChallengeRow = {
    id: string;
    user_id: string;
    channel: "email" | "whatsapp";
    destination: string;
    otp_hash: string;
    expires_at: string;
    attempts: number;
    verified_at: string | null;
    reset_token_hash: string | null;
    reset_token_expires_at: string | null;
    consumed_at: string | null;
    created_at: string;
    updated_at: string;
};

export type RefreshTokenRow = {
    id: string;
    user_id: string;
    token_hash: string;
    expires_at: string;
    revoked_at: string | null;
    created_at: string;
};

export type AuthTables = {
    users: TableDefinition<UserRow, {
        id?: string;
        email?: string | null;
        phone?: string | null;
        app_metadata?: Record<string, unknown>;
        user_metadata?: Record<string, unknown>;
        disabled?: boolean;
        created_at?: string;
        updated_at?: string;
    }, Partial<UserRow>>;
    profiles: TableDefinition<ProfileRow, {
        user_id: string;
        email: string;
        phone?: string | null;
        first_name?: string | null;
        last_name?: string | null;
        providers?: string[];
        created_at?: string;
        updated_at?: string;
    }, Partial<ProfileRow>>;
    auth_otp_challenges: TableDefinition<OtpChallengeRow, {
        id?: string;
        user_id: string;
        channel: OtpChallengeRow["channel"];
        destination: string;
        otp_hash: string;
        expires_at: string;
        attempts?: number;
        verified_at?: string | null;
        reset_token_hash?: string | null;
        reset_token_expires_at?: string | null;
        consumed_at?: string | null;
        created_at?: string;
        updated_at?: string;
    }, Partial<OtpChallengeRow>>;
    auth_refresh_tokens: TableDefinition<RefreshTokenRow, {
        id?: string;
        user_id: string;
        token_hash: string;
        expires_at: string;
        revoked_at?: string | null;
        created_at?: string;
    }, Partial<RefreshTokenRow>>;
};
