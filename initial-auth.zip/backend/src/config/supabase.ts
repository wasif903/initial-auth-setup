﻿throw new Error("Supabase has been removed from this backend. Use config/database.ts for PostgreSQL access.");
