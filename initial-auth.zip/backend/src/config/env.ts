import "dotenv/config";
import { z } from "zod";

const booleanFromString = z.enum(["true", "false"]).transform((value) => value === "true");

const envSchema = z.object({
    NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
    PORT: z.coerce.number().int().positive().default(4000),
    CORS_ORIGIN: z.string().default("*"),
    DATABASE_URL: z.string().min(1),
    DATABASE_SSL: booleanFromString.default(false),
    JWT_SECRET: z.string().min(32),
    JWT_ACCESS_EXPIRES_SECONDS: z.coerce.number().int().positive().default(3600),
    JWT_REFRESH_EXPIRES_DAYS: z.coerce.number().int().positive().default(30),
    DEFAULT_PASSWORDLESS_OTP: z.string().regex(/^\d{6}$/).default("123456"),
    GOOGLE_CLIENT_ID: z.string().trim().min(1).optional(),
    APPLE_CLIENT_ID: z.string().trim().min(1).optional(),
    ADMIN_EMAILS: z.string().default("admin1@gmail.com,admin2@gmail.com"),
    SMTP_HOST: z.string().min(1).default("smtp.gmail.com"),
    SMTP_PORT: z.coerce.number().int().positive().default(465),
    SMTP_SECURE: booleanFromString.default(true),
    SMTP_USER: z.string().email(),
    SMTP_PASS: z.string().min(1),
    SMTP_FROM: z.string().min(1),
    META_WHATSAPP_API_VERSION: z.string().min(1),
    META_WHATSAPP_PHONE_NUMBER_ID: z.string().min(1),
    META_WHATSAPP_ACCESS_TOKEN: z.string().min(1),
    META_WHATSAPP_OTP_TEMPLATE_NAME: z.string().min(1),
    META_WHATSAPP_TEMPLATE_LANGUAGE: z.string().min(1).default("en_US"),
    OTP_PEPPER: z.string().min(32),
    OTP_EXPIRY_MINUTES: z.coerce.number().int().positive().default(10),
    RESET_TOKEN_EXPIRY_MINUTES: z.coerce.number().int().positive().default(15),
    OTP_RESEND_SECONDS: z.coerce.number().int().positive().default(60),
    OTP_MAX_ATTEMPTS: z.coerce.number().int().positive().default(5),
});

const parsed = envSchema.safeParse(process.env);
if (!parsed.success) {
    const issues = parsed.error.issues.map((issue) => `${issue.path.join(".")}: ${issue.message}`).join("; ");
    throw new Error(`Invalid environment configuration: ${issues}`);
}

export const env = parsed.data;
