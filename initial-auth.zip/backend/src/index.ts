import express from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import path from "path";
import { env } from "./config/env";
import authRouter from "./modules/auth/auth.router";
import { AppError } from "./utils/AppError";
import { errorHandler } from "./middlewares/errorHandler";
import { seedAdminAccounts } from "./seeders/admin.seeder";

const app = express();

const allowedOrigins = env.CORS_ORIGIN === "*"
    ? true
    : env.CORS_ORIGIN.split(",").map((origin) => origin.trim());

app.use(cors({ origin: allowedOrigins, credentials: true }));
app.use(express.json({ limit: "1mb" }));
app.use(cookieParser());
app.use("/uploads", express.static(path.join(process.cwd(), "uploads")));

app.get("/health", (_request, response) => {
    response.json({ status: "up", timestamp: new Date().toISOString() });
});

app.use("/auth", authRouter);
app.use((_request, _response, next) =>
    next(new AppError("Route not found", 404, "NOT_FOUND")),
);
app.use(errorHandler);

seedAdminAccounts()
    .then(() => {
        console.log("Admin seed completed");
        app.listen(env.PORT, () => {
            console.log(`Nutryx API running on port ${env.PORT}`);
        });
    })
    .catch((error: unknown) => {
        console.error(
            error instanceof Error ? error.message : error,
        );
        process.exit(1);
    });
