﻿import type { NextFunction, Request, Response } from "express";
import type { AuthUser } from "../types/auth";
import { AppError } from "../utils/AppError";
import { verifyAccessToken } from "../utils/authTokens";
import { findUserById } from "../modules/auth/auth.profile.service";

export interface AuthenticatedRequest extends Request { authUser?: AuthUser; accessToken?: string; }

export const authenticate = async (request: AuthenticatedRequest, _response: Response, next: NextFunction): Promise<void> => {
    try {
        const authorization = request.headers.authorization;
        const token = authorization?.startsWith("Bearer ") ? authorization.slice(7).trim() : undefined;
        if (!token) throw new AppError("Authentication required", 401, "UNAUTHORIZED");
        const payload = verifyAccessToken(token);
        const user = await findUserById(payload.sub);
        if (!user) throw new AppError("Invalid or expired token", 401, "INVALID_TOKEN");
        request.authUser = user;
        request.accessToken = token;
        next();
    } catch (error) { next(error); }
};
