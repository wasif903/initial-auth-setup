create table if not exists auth_social_identities (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id) on delete cascade,
  provider text not null check (provider in ('google', 'apple')),
  subject text not null,
  created_at timestamptz not null default now(),
  unique (provider, subject),
  unique (user_id, provider)
);

create index if not exists idx_auth_social_identities_user_id
  on auth_social_identities(user_id);