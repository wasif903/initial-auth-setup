create extension if not exists pgcrypto;

create or replace function set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create table if not exists users (
  id uuid primary key default gen_random_uuid(),
  email text unique,
  phone text unique,
  app_metadata jsonb not null default '{}'::jsonb,
  user_metadata jsonb not null default '{}'::jsonb,
  disabled boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (email is not null or phone is not null)
);

create trigger set_users_updated_at
  before update on users
  for each row execute function set_updated_at();

create table if not exists profiles (
  user_id uuid primary key references users(id) on delete cascade,
  email text not null unique,
  phone text unique,
  first_name text,
  last_name text,
  providers text[] not null default '{}'::text[],
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists auth_otp_challenges (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id) on delete cascade,
  channel text not null check (channel in ('email', 'whatsapp')),
  destination text not null,
  otp_hash text not null,
  expires_at timestamptz not null,
  attempts int not null default 0 check (attempts >= 0),
  verified_at timestamptz,
  reset_token_hash text unique,
  reset_token_expires_at timestamptz,
  consumed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists auth_refresh_tokens (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references users(id) on delete cascade,
  token_hash text not null unique,
  expires_at timestamptz not null,
  revoked_at timestamptz,
  created_at timestamptz not null default now()
);

create index if not exists idx_auth_otp_challenges_user_created
  on auth_otp_challenges(user_id, created_at desc);

create index if not exists idx_auth_refresh_tokens_user_id
  on auth_refresh_tokens(user_id);

create trigger set_profiles_updated_at
  before update on profiles
  for each row execute function set_updated_at();

create trigger set_auth_otp_challenges_updated_at
  before update on auth_otp_challenges
  for each row execute function set_updated_at();